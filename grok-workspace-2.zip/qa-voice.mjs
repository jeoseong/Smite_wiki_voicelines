import { chromium } from 'playwright';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox','--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', (e) => errors.push('PAGE ' + e.message));
page.on('console', (msg) => { if (msg.type() === 'error') errors.push('CON ' + msg.text()); });

await page.goto('http://127.0.0.1:8080/', { waitUntil: 'domcontentloaded', timeout: 30000 });
await page.waitForTimeout(800);
const frameEl = page.locator('iframe');
const frame = page.frameLocator('iframe');
await frame.locator('#smiteChatLog').waitFor({ timeout: 8000 });
await page.waitForTimeout(900);

const chat = await frame.locator('#smiteChatLog').innerText();
const hint = await frame.locator('.smite-chat-hint').innerText();
const tab = await frame.locator('.smite-chat-tab').innerText();
const bg = await frame.locator('#screenMain').evaluate((el) => getComputedStyle(el).backgroundImage);
const placeholder = await frame.locator('#rosterSearch').getAttribute('placeholder');
const vgsBtn = await frame.locator('#btnVpVGS').innerText();

const report = { chat, hint, tab, bgIncludes: bg.includes('bg-conquest'), placeholder, vgsBtn };

// gods -> god -> voice -> back should show god, not blank
await frame.locator('.nav-item', { hasText: 'DEUSES' }).click();
await frame.locator('.god-select-card-name', { hasText: 'IZANAMI' }).click();
await frame.locator('text=PACOTE DE VOZ').click();
await frame.locator('#screenVoicebankView').waitFor({ state: 'visible' });
await frame.locator('#backBtn').click();
await page.waitForTimeout(200);
const godVisible = await frame.locator('#screenGodView').evaluate((el) => getComputedStyle(el).display !== 'none');
const godName = await frame.locator('#extGodName').innerText();
const mainVisible = await frame.locator('#screenMain').evaluate((el) => getComputedStyle(el).display !== 'none');
const voiceVisible = await frame.locator('#screenVoicebankView').evaluate((el) => getComputedStyle(el).display !== 'none');
report.afterBack = { godVisible, godName, mainVisible, voiceVisible };

// appearances tab then voice pack should stay on appearances (skin panel)
await frame.locator('#tabBtnSkins').click();
await frame.locator('text=PACOTE DE VOZ').click();
await page.waitForTimeout(200);
const skinPanel = await frame.locator('#vpSkinSelectionPanel').evaluate((el) => getComputedStyle(el).display !== 'none');
const godVoicePanel = await frame.locator('#vpDynamicPanel').evaluate((el) => getComputedStyle(el).display !== 'none');
const godBtn = await frame.locator('#btnVpGod').innerText();
report.stayOnSkins = { skinPanel, godVoicePanel, godBtn };

// click a skin card should remain on skin panel
await frame.locator('#vpSkinCardsGrid .smite-skin-card').nth(1).click();
await page.waitForTimeout(150);
report.afterSkinClick = {
  skinPanel: await frame.locator('#vpSkinSelectionPanel').evaluate((el) => getComputedStyle(el).display !== 'none'),
  godPanel: await frame.locator('#vpDynamicPanel').evaluate((el) => getComputedStyle(el).display !== 'none'),
  godBtn: await frame.locator('#btnVpGod').innerText(),
};

// VGS headers + inline edit
await frame.locator('#btnVpVGS').click();
await page.waitForTimeout(150);
const headers = await frame.locator('.vgs-wiki-table th').evaluateAll((els) => els.map((el) => ({
  text: el.textContent.trim(),
  align: getComputedStyle(el).textAlign,
})));
report.headers = headers;

const codeEdit = frame.locator('.vgs-code-cell .vgs-inline-edit').first();
await codeEdit.click();
await codeEdit.evaluate((el) => { el.innerText = 'ZZ'; el.dispatchEvent(new Event('blur')); });
await page.waitForTimeout(100);
report.codeAfter = await frame.locator('.vgs-code-cell').first().innerText();

// outcome paragraph via modal
await frame.locator('button', { hasText: 'Editar Título' }).first().click();
// open first row pencil instead
await frame.locator('#editVgsModal').evaluate((el) => { el.style.display = 'none'; });
await frame.locator('.vgs-wiki-table tbody button').first().click();
await frame.locator('#modalVgsResult').fill('Linha um');
await frame.locator('button', { hasText: 'Novo parágrafo' }).click();
const ta = await frame.locator('#modalVgsResult').inputValue();
report.paragraph = JSON.stringify(ta);
await frame.locator('#editVgsModal button', { hasText: 'Salvar' }).click();
await page.waitForTimeout(200);
report.outcomeHtml = await frame.locator('.vgs-outcome-cell').first().innerText();

// category target select appears
await frame.locator('.vgs-wiki-table tbody button').first().click();
await frame.locator('#modalVgsIsCat').selectOption('true');
const targetVisible = await frame.locator('#groupVgsTarget').evaluate((el) => getComputedStyle(el).display !== 'none');
report.targetVisible = targetVisible;
await frame.locator('#editVgsModal button', { hasText: 'Cancelar' }).click();

// audio play/pause with generated wav
const handle = await page.locator('iframe').elementHandle();
const rawFrame = await handle.contentFrame();
await rawFrame.evaluate(() => {
  const sr = 8000;
  const samples = sr * 0.3;
  const buffer = new ArrayBuffer(44 + samples * 2);
  const view = new DataView(buffer);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); view.setUint32(4, 36 + samples * 2, true); w(8, 'WAVEfmt ');
  view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true);
  view.setUint32(24, sr, true); view.setUint32(28, sr * 2, true); view.setUint16(32, 2, true); view.setUint16(34, 16, true);
  w(36, 'data'); view.setUint32(40, samples * 2, true);
  for (let i = 0; i < samples; i++) view.setInt16(44 + i * 2, Math.sin(i / 8) * 8000, true);
  const bytes = new Uint8Array(buffer);
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  const url = 'data:audio/wav;base64,' + btoa(bin);
  const row = getActiveVgs()[0].rows[2];
  row.audios = [url];
  row.audioUrl = url;
  row.result = 'Ok teste';
  renderVgsWikiTables();
});
const playBtn = frame.locator('.audio-play-btn').first();
await playBtn.click();
await page.waitForTimeout(250);
report.whilePlaying = {
  icon: await playBtn.innerText(),
  status: await frame.locator('#statusAudio').innerText(),
  chat: await frame.locator('#smiteChatLog').innerText(),
};
await playBtn.click();
await page.waitForTimeout(150);
report.whilePaused = {
  icon: await playBtn.innerText(),
  status: await frame.locator('#statusAudio').innerText(),
};

// pencil drag
await frame.locator('#globalPageEditBtn').dispatchEvent('pointerdown', { clientX: 1000, clientY: 600, button: 0 });
report.pencilExists = await frame.locator('#globalPageEditBtn').count();

// add 7 skins quickly without image then with a tiny png via function
await rawFrame.evaluate(async () => {
  const god = godsDatabase[selectedGodIdx];
  const before = god.skins.length;
  for (let i = god.skins.length; i < 7; i++) {
    god.skins.push({ id: 'skin_t' + i, name: 'Skin ' + (i + 1), tier: 'EXCLUSIVO', img: god.img });
  }
  // simulate image attach on 7th
  const canvas = document.createElement('canvas');
  canvas.width = 80; canvas.height = 100;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#2266aa'; ctx.fillRect(0,0,80,100);
  god.skins[6].img = canvas.toDataURL('image/jpeg', 0.8);
  await saveStorageData();
  return before;
});
const stored = await rawFrame.evaluate(async () => {
  const db = await new Promise((resolve, reject) => {
    const req = indexedDB.open('smite_wiki_db', 1);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return new Promise((resolve) => {
    const tx = db.transaction('kv', 'readonly');
    const r = tx.objectStore('kv').get('gods');
    r.onsuccess = () => {
      const gods = r.result;
      const skins = gods && gods[0] && gods[0].skins;
      resolve({ count: skins ? skins.length : 0, seventhStarts: skins && skins[6] ? String(skins[6].img).slice(0, 30) : null, name: skins && skins[6] && skins[6].name });
    };
  });
});
report.seventh = stored;

console.log(JSON.stringify({ report, errors }, null, 2));
await browser.close();
