import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <iframe
      title="SMITE Wiki & Database Engine"
      src="/voicebanks.html"
      className="fixed inset-0 h-dvh w-full border-0 bg-[#080c14]"
    />
  );
}
